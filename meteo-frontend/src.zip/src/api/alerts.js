import { api } from "./api";

export async function getAlerts(city) {
  const res = await api.get(`/alerts/${encodeURIComponent(city)}`);
  return res.data;
}
