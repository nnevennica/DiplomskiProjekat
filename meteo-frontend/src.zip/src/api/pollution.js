import { api } from "./api";

export async function getPollutionSeries(city) {
  const c = encodeURIComponent(city || "Subotica");
  const res = await api.get(`/pollution/${c}/series`);
  return res.data;
}
