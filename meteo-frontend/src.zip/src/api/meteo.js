import { api } from "./api";

export async function getMeteoSeries(city) {
  const c = encodeURIComponent(city || "Subotica");
  const res = await api.get(`/meteo/${c}/series`);
  return res.data;
}

