import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  CartesianGrid,
} from "recharts";

import { getMeteoSeries } from "../api/meteo";
import { getPollutionSeries } from "../api/pollution";
import { getCities } from "../api/cities";
import { getAlerts } from "../api/alerts";

export default function Dashboard() {
  const navigate = useNavigate();
  const user = useMemo(
    () => JSON.parse(localStorage.getItem("user") || "null"),
    []
  );

  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(user?.city || "Subotica");

  const [meteoPoints, setMeteoPoints] = useState([]);
  const [pollutionPoints, setPollutionPoints] = useState([]);

  const [error, setError] = useState("");

  const [activeGroup, setActiveGroup] = useState("meteo"); 
  const [activeMetric, setActiveMetric] = useState("temp"); 

  const [lastAlertKey, setLastAlertKey] = useState("");

  function logout() {
    localStorage.removeItem("accessToken");
    localStorage.removeItem("user");
    navigate("/");
  }


  useEffect(() => {
    (async () => {
      try {
        const list = await getCities();
        setCities(list);

        const userCity = user?.city?.trim();
        const found =
          userCity &&
          list.find((c) => c.toLowerCase() === userCity.toLowerCase());

        if (found) setSelectedCity(found);
        else if (list.length > 0) setSelectedCity(list[0]);
      } catch (e) {
        console.error(e);
        const fallback = ["Subotica", "NoviSad", "Beograd", "Nis", "Uzice"];
        setCities(fallback);

        const userCity = user?.city?.trim();
        const found =
          userCity &&
          fallback.find((c) => c.toLowerCase() === userCity.toLowerCase());

        setSelectedCity(found || "Subotica");
      }
    })();
  }, [user]);

  async function load() {
    try {
      setError("");

      if (activeGroup === "meteo") {
        const data = await getMeteoSeries(selectedCity);
        const points = Array.isArray(data) ? data : data?.points || [];
        setMeteoPoints(points);
      } else {
        const data = await getPollutionSeries(selectedCity);
        const points = Array.isArray(data) ? data : data?.points || [];
        setPollutionPoints(points);
      }
    } catch (e) {
      console.error(e);
      setError(
        "Ne mogu da učitam merenja. Proveri da li backend radi i da li si ulogovana."
      );
    }
  }

  async function loadAlerts() {
    try {
      
      const data = await getAlerts(selectedCity);

      const items = Array.isArray(data) ? data : data?.items || [];
      if (!items.length) return;

      const key = items
        .map((a) => a.key || a.id || a.ts || `${a.title}|${a.message}`)
        .join("||");

      if (key === lastAlertKey) return;
      setLastAlertKey(key);

      items.forEach((a) => {
        alert(`⚠️ ${a.title}\n${a.message}`);
      });
    } catch (e) {
      console.warn("Alert fetch failed", e);
    }
  }

  useEffect(() => {
    if (!selectedCity) return;

    load();
    loadAlerts();

    const id = setInterval(() => {
      load();
      loadAlerts();
    }, 5000);

    return () => clearInterval(id);
  }, [selectedCity, activeGroup]);

  function switchToMeteo() {
    setActiveGroup("meteo");
    setActiveMetric("temp");
  }

  function switchToPollution() {
    setActiveGroup("pollution");
    setActiveMetric("pm25");
  }

  const chartTitle =
    activeGroup === "meteo"
      ? activeMetric === "temp"
        ? "Temperatura (°C)"
        : activeMetric === "hum"
        ? "Vlažnost (%)"
        : "Pritisak (hPa)"
      : activeMetric === "pm25"
      ? "PM2.5"
      : activeMetric === "pm10"
      ? "PM10"
      : "O₃";

  return (
    <div className="dashBg">
      <div className="dashContainer">
        <div className="dashHeaderCard">
          <div className="dashUser">
            <div className="dashTitle">
              {user?.firstName} {user?.lastName}
            </div>
            <div className="dashSub">
              {user?.email} • Lokacija: <b>{user?.city}</b>
            </div>
          </div>

          <div className="dashActions">
            <div className="dashField">
              <label>Prikaži grad</label>
              <select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                disabled={cities.length === 0}
              >
                {cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <button className="ghostBtn" onClick={logout}>
              Logout
            </button>
          </div>
        </div>

        {/* TABOVI */}
        <div className="dashTabs">
          <button
            className={activeGroup === "meteo" ? "tabBtn active" : "tabBtn"}
            onClick={switchToMeteo}
          >
            Meteo stanice
          </button>

          <button
            className={
              activeGroup === "pollution" ? "tabBtn active" : "tabBtn"
            }
            onClick={switchToPollution}
          >
            Kvalitet vazduha
          </button>
        </div>

        {/* CHIPOVI */}
        <div className="dashChips">
          {activeGroup === "meteo" ? (
            <>
              <button
                className={activeMetric === "temp" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("temp")}
              >
                Temperatura
              </button>
              <button
                className={activeMetric === "hum" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("hum")}
              >
                Vlažnost
              </button>
              <button
                className={activeMetric === "press" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("press")}
              >
                Pritisak
              </button>
            </>
          ) : (
            <>
              <button
                className={activeMetric === "pm25" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("pm25")}
              >
                PM2.5
              </button>
              <button
                className={activeMetric === "pm10" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("pm10")}
              >
                PM10
              </button>
              <button
                className={activeMetric === "o3" ? "chip active" : "chip"}
                onClick={() => setActiveMetric("o3")}
              >
                O₃
              </button>
            </>
          )}
        </div>

        {error ? <div className="dashError">{error}</div> : null}

        {/* GRAF */}
        <div className="chartCard">
          <div className="chartHeader">
            <div className="chartTitle">
              {selectedCity} — {chartTitle}
            </div>
            <div className="chartNote">Avg stanice • real-time</div>
          </div>

          <div className="chartBody">
            <ResponsiveContainer>
              <LineChart
                data={activeGroup === "meteo" ? meteoPoints : pollutionPoints}
                margin={{ top: 10, right: 20, left: 0, bottom: 0 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="label" />
                <YAxis />
                <Tooltip />
                <Legend />

                {/* METEO */}
                {activeGroup === "meteo" && activeMetric === "temp" && (
                  <Line
                    type="monotone"
                    dataKey="tempAvg"
                    name="Temp (°C)"
                    dot={false}
                  />
                )}
                {activeGroup === "meteo" && activeMetric === "hum" && (
                  <Line
                    type="monotone"
                    dataKey="humAvg"
                    name="Vlaga (%)"
                    dot={false}
                  />
                )}
                {activeGroup === "meteo" && activeMetric === "press" && (
                  <Line
                    type="monotone"
                    dataKey="pressAvg"
                    name="Pritisak (hPa)"
                    dot={false}
                  />
                )}

                {/* POLLUTION */}
                {activeGroup === "pollution" && activeMetric === "pm25" && (
                  <Line
                    type="monotone"
                    dataKey="pm25Avg"
                    name="PM2.5"
                    dot={false}
                  />
                )}
                {activeGroup === "pollution" && activeMetric === "pm10" && (
                  <Line
                    type="monotone"
                    dataKey="pm10Avg"
                    name="PM10"
                    dot={false}
                  />
                )}
                {activeGroup === "pollution" && activeMetric === "o3" && (
                  <Line type="monotone" dataKey="o3Avg" name="O₃" dot={false} />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
