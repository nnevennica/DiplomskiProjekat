import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { login as loginApi } from "../api/auth";
import RegisterModal from "../components/RegisterModal";

const AVATAR = "/img.jpg";

export default function LoginPage() {
  const navigate = useNavigate();

  const [showRegister, setShowRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setError("");

    const emailNorm = email.trim().toLowerCase();
    const passNorm = password.trim();

    if (!emailNorm || !emailNorm.includes("@")) return setError("Unesite validan mail.");
    if (!passNorm) return setError("Unesite šifru."); 

    setLoading(true);
    try {
      const data = await loginApi({ email: emailNorm, password: passNorm });

      localStorage.setItem("accessToken", data.accessToken);
      localStorage.setItem("user", JSON.stringify(data.user));

      navigate("/dashboard");
    } catch (err) {
      const msg =
        err?.response?.data?.toString?.() ||
        err?.response?.data?.title ||
        "Pogrešan email ili šifra.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  function onRegisterSuccess(data) {
    localStorage.setItem("accessToken", data.accessToken);
    localStorage.setItem("user", JSON.stringify(data.user));
    setShowRegister(false);
    navigate("/dashboard");
  }

  return (
    <div className="authBg">
      <div className="authCard">
        <div className="authLeft">
          <div className="illustration">
            <img src={AVATAR} alt="Weather" className="loginAvatar" />
          </div>
        </div>

        <div className="authRight">
          <h2 className="title">Member Login</h2>

          <form onSubmit={submit} className="authForm">
            <div className="inputWrap">
              <span className="icon">✉</span>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                autoComplete="email"
                inputMode="email"
              />
            </div>

            <div className="inputWrap">
              <span className="icon">🔒</span>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                autoComplete="current-password"
              />
            </div>

            {error ? <div className="errorBox">{error}</div> : null}

            <button className="primaryBtn" disabled={loading}>
              {loading ? "LOGIN..." : "LOGIN"}
            </button>
          </form>

          <div className="createRow">
            <button
              className="linkBtn"
              type="button"
              onClick={() => setShowRegister(true)}
            >
              Create your Account →
            </button>
          </div>
        </div>
      </div>

      <RegisterModal
        open={showRegister}
        onClose={() => setShowRegister(false)}
        onSuccess={onRegisterSuccess}
      />
    </div>
  );
}